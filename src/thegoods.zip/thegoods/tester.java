import java.util.*;
import java.text.*;
import java.io.*;
 public class tester {
 
 
 
     public static void main (String[] args){
        LoginState login1 = LoginState.instance();
        login1.run(); 
    }
}
